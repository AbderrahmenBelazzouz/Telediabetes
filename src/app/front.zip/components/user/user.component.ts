import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../class/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users:any;
  user = new User();
  u:any;

  constructor( private userService: UserService, private router:Router) { };

  ngOnInit(): void {
    this.getUsers();
  }

  getUsers(){
    this.userService.getUsers().subscribe(
      res =>{
        this.users = res;
      });
  }

  registerUser(){
    this.userService.addUser(this.user).subscribe(
      res =>{
        this.u = res;
        //console.log();
        this.router.navigate(['users']);
      });
  }

  deleteUser(id){
    this.userService.deleteUser(id).subscribe(
      res =>{
          console.log(res);
          this.getUsers();
      }
    )
  }

}
