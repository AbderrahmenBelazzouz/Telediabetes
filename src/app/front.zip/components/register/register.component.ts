import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../class/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user = new User();
  u:any;

  constructor(private userService: UserService, private router:Router) { }

  ngOnInit(): void {
  }

  registerUser(){
    this.userService.addUser(this.user).subscribe(
      res =>{
        this.u = res;
        //console.log();
        alert("User created succesfully");
        this.router.navigate(['users']);
      });
  }

}
