import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../class/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {

  id:any;
  data: any;
  user = new User();

  constructor(private activatedRoute:ActivatedRoute, private router:Router, private userService: UserService) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.params.id;

    this.getData();
  }

  getData(){
    this.userService.getUserById(this.id).subscribe(
      res=>{
        this.data = res;
        this.user = this.data;
        console.log("id is :"+this.user.id)
        console.log("username is :"+this.user.username)
        console.log("password is :"+this.user.password)
        console.log("role is :"+this.user.role)
        console.log("state is :"+this.user.state)

      }
    )
  }

  updateUser(){
    this.userService.updateUser(this.id, this.user).subscribe(
      res=>{
        this.router.navigate(['users']);
      }
    )
  }

}
