import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

  getUsers(){
    return this.httpClient.get('http://localhost:9001/users');
  }
  getUserById(id){
    return this.httpClient.get('http://localhost:9001/users/'+id);
  }

  addUser(data){
    return this.httpClient.post('http://localhost:9001/register',data);
  }

  deleteUser(id){
    return this.httpClient.delete('http://localhost:9001/users/delete/'+id);
  }

  updateUser(id, data){
    return this.httpClient.put('http://localhost:9001/users/update/'+id,data);
  }


}
